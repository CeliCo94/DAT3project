package com.himmerland.hero.service.helperclasses.enums;

public enum Criticality {
    High, //0
    Medium, //1
    Low; //2
}
