package com.himmerland.hero.service.helperclasses.id;

public interface Identifiable {
    String getId();
    void setId(String id);
}
