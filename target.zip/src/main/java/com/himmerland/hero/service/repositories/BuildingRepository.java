package com.himmerland.hero.service.repositories;

public class BuildingRepository {
    
}
