package com.himmerland.hero.domain.rules;

public class RuleContext {
    
}
